import { handlers } from "@/auth"
export const { GET, POST } = handlers
