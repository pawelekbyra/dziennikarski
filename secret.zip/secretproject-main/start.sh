#!/bin/bash
nohup yarn dev > app.log 2>&1 &
