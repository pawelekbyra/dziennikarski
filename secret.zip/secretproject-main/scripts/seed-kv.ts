async function seed() {
  console.log('Seeding script is disabled.');
}

seed();
